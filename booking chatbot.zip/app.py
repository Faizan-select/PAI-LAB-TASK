from flask import Flask, render_template, request, jsonify
import datetime
import json
import re

app = Flask(__name__)

# Simulated database for bookings
bookings = []
deleted_bookings = []
# Track the last booking for confirmation
last_booking = None
awaiting_confirmation = False
# Transaction history
transactions = []

# List of available services with prices
services = {
    "hotel booking": 150.00,
    "room booking": 80.00,
    "suite booking": 250.00
}

def parse_date(message):
    message = message.lower()
    if "tomorrow" in message:
        return (datetime.datetime.now() + datetime.timedelta(days=1)).strftime("%Y-%m-%d")
    elif "next week" in message:
        return (datetime.datetime.now() + datetime.timedelta(days=7)).strftime("%Y-%m-%d")
    date_match = re.search(r'(january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}', message)
    if date_match:
        date_str = date_match.group(0)
        try:
            return datetime.datetime.strptime(f"{date_str} 2025", "%B %d %Y").strftime("%Y-%m-%d")
        except:
            pass
    return datetime.datetime.now().strftime("%Y-%m-%d")

def parse_time(message):
    message = message.lower()
    time_match = re.search(r'(\d{1,2})\s*(am|pm)', message)
    if time_match:
        hour = int(time_match.group(1))
        period = time_match.group(2)
        if period == "pm" and hour != 12:
            hour += 12
        elif period == "am" and hour == 12:
            hour = 0
        return f"{hour:02d}:00"
    return "12:00"

def process_booking_query(message):
    global last_booking, awaiting_confirmation, transactions
    message = message.lower().strip()
    
    # Log the received message for debugging
    print(f"Received message: {message}")
    
    # Handle confirmation response
    if awaiting_confirmation:
        if "yes" in message:
            bookings.append(last_booking)
            # Log transaction for the charge
            transactions.append({
                "booking_id": last_booking['id'],
                "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "type": "Charge",
                "amount": last_booking['price'],
                "status": "Completed"
            })
            awaiting_confirmation = False
            return f"Booking confirmed for {last_booking['service']} on {last_booking['date']} at {last_booking['time']}. Price: ${last_booking['price']:.2f}. Booking ID: {last_booking['id']}"
        elif "no" in message:
            awaiting_confirmation = False
            last_booking = None
            return "Booking cancelled. Let me know if you'd like to book something else!"
        else:
            return "Please reply with 'yes' or 'no' to confirm or cancel the booking."

    # View transaction history
    if "view transactions" in message or "transaction history" in message:
        if not transactions:
            return "No transactions found."
        
        # Prepare CSV-like string for display and download
        csv_header = "Booking ID,Date,Type,Amount,Status\n"
        csv_rows = ""
        for transaction in transactions:
            csv_rows += f"{transaction['booking_id']},{transaction['date']},{transaction['type']},${transaction['amount']:.2f},{transaction['status']}\n"
        
        # Display in chat (formatted for readability)
        response = "Transaction History:\n\n"
        for transaction in transactions:
            response += f"Booking ID: {transaction['booking_id']}, Date: {transaction['date']}, Type: {transaction['type']}, Amount: ${transaction['amount']:.2f}, Status: {transaction['status']}\n"
        response += f"\nSummary: You have {len(transactions)} transaction(s)."
        
        # Attach CSV content for download (to be handled by frontend)
        response_data = {
            "display": response,
            "csv_content": csv_header + csv_rows
        }
        return json.dumps(response_data)

    # View booking history (active and deleted)
    if "view history" in message or "booking history" in message:
        response = "Booking History:\n\nActive Bookings:\n"
        if not bookings:
            response += "No active bookings found.\n"
        else:
            for booking in bookings:
                response += f"ID: {booking['id']}, Service: {booking['service']}, Date: {booking['date']}, Time: {booking['time']}, Price: ${booking['price']:.2f}, Status: {booking['status']}\n"
        
        response += "\nDeleted Bookings:\n"
        if not deleted_bookings:
            response += "No deleted bookings found.\n"
        else:
            for booking in deleted_bookings:
                response += f"ID: {booking['id']}, Service: {booking['service']}, Date: {booking['date']}, Time: {booking['time']}, Price: ${booking['price']:.2f}, Status: {booking['status']}\n"
        
        response += f"\nSummary: You have {len(bookings)} active booking(s) and {len(deleted_bookings)} deleted booking(s)."
        return response

    # Prioritize "view bookings"
    if "view bookings" in message or "my bookings" in message or "which things i booked" in message:
        if not bookings:
            return "No bookings found"
        response = "Your bookings:\n"
        for booking in bookings:
            response += f"ID: {booking['id']}, Service: {booking['service']}, Date: {booking['date']}, Time: {booking['time']}, Price: ${booking['price']:.2f}, Status: {booking['status']}\n"
        response += f"\nSummary: You have {len(bookings)} active booking(s)."
        return response
    
    # Check for booking command
    if ("book a" in message or "reserve a" in message) or (message.startswith("book ") or message.startswith("reserve ")):
        if "for which thing" in message:
            response = "Please select a service to book:\n"
            for service, price in services.items():
                response += f"- {service} (${price:.2f})\n"
            response += "Reply with the service name (e.g., 'book hotel booking') to proceed."
            print(f"Sending response: {response}")
            return response
        
        # Check if a specific service is mentioned
        service_to_book = next((s for s in services.keys() if s in message), None)
        if service_to_book:
            date = parse_date(message)
            time = parse_time(message)
            
            last_booking = {
                "id": len(bookings) + 1,
                "date": date,
                "time": time,
                "service": service_to_book,
                "price": services[service_to_book],
                "status": "Pending",
                "timestamp": datetime.datetime.now().isoformat()
            }
            awaiting_confirmation = True
            return f"Please confirm: Booking for {service_to_book} on {date} at {time}. Price: ${services[service_to_book]:.2f}. Reply 'yes' to confirm or 'no' to cancel."
        else:
            response = "Please specify a service. Available options:\n"
            for service, price in services.items():
                response += f"- {service} (${price:.2f})\n"
            response += "Reply with 'book [service name]' (e.g., 'book hotel booking') to book."
            return response
    
    elif "cancel" in message and "booking" in message:
        try:
            # Check if a booking ID is provided
            parts = message.split()
            if len(parts) > 2 and parts[1] == "booking":
                booking_id = int(parts[2])
                for booking in bookings:
                    if booking["id"] == booking_id:
                        booking['status'] = "Cancelled"
                        deleted_bookings.append(booking)
                        # Log transaction for the refund
                        transactions.append({
                            "booking_id": booking['id'],
                            "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "type": "Refund",
                            "amount": booking['price'],
                            "status": "Completed"
                        })
                        bookings.remove(booking)
                        return f"Booking {booking_id} cancelled successfully. Amount refunded: ${booking['price']:.2f}"
                return "Booking ID not found"
            return "Please provide a valid Booking ID (e.g., 'cancel booking 1')"
        except (ValueError, IndexError):
            return "Please provide a valid Booking ID (e.g., 'cancel booking 1')"
    
    return "I can help with booking, cancelling, viewing reservations, or viewing transaction history. Try saying 'book a service', 'cancel booking 1', 'view bookings', or 'view transactions'. For specific bookings, say 'book for which thing' to see options."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    response = process_booking_query(user_message)
    print(f"Returning response: {response}")
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)